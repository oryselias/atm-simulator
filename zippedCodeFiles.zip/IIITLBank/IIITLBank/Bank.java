package IIITLBank;

import java.sql.*;

public class Bank{


   public  boolean verifyCard(int number,User userobj) {

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            String user="root";
            String password="Yeageren@7777";
            String url="jdbc:mysql://localhost:3306/grp_project";
            Connection con =DriverManager.getConnection(url,user,password);

            Statement statement=con.createStatement();

            ResultSet resultset=statement.executeQuery("Select * from cards");

            while(resultset.next())
            {
                if(resultset.getInt("cardNumber")==number)
                {
                    int userID=resultset.getInt("ID");
                    String userName=resultset.getString("Name")	;
                    int userPIN=resultset.getInt("PIN");
                    int userBal=resultset.getInt("acc_bal");
                    String userCity=resultset.getString("CITY");
                    int cardNumber=number;
                    String userMail=resultset.getString("mail")	;
                    userobj=new User(userID,userName,userPIN,userBal,userCity,cardNumber,userMail);

                    return true;

                }

            }
            return false;


        }

        catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}
