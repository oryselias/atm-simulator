package IIITLBank;

public class Header {
    public Header() {
    }

    public static void head() {
        System.out.println("\n-------------------------------------------------------------------------");
        System.out.println(" ");
        System.out.println("                         THE BANK OF IIITL\n");
    }
}
